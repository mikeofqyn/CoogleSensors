#ifndef COGGLEESP8266_SENSOR_H
#define COGGLEESP8266_SENSOR_H

//
// Configuration
//

#define SERIAL_BAUD 115200

#define SENSOR_STATUS_INTERVAL  10000  // 10s

const char MQTT_CLIENT_ID[]       =  "ESP_SENSOR";

//
// Topics to publish to
//
const char ESP8266_SENSOR_STATUS_TOPIC[]         =  "sensor/status";
const char ESP8266_SENSOR_STATS_TOPIC[]          =  "sensor/statistics";
const char ESP8266_SENSOR_ERROR_TOPIC[]          =  "sensor/error";
const char ESP8266_SENSOR_TOPIC_PREFIX[]  =         "sensor/sensor/";  // prefix for sensed library packets

//
// Status srtings and error codes
//
const char SENSOR_STATUS_READY[]         =  "READY";
const char SENSOR_STATUS_SHUTDOWN[]      =  "SHUTDOWN";

const char SENSOR_ERROR_BAD_COMMAND[]    =  "BAD_COMMAND";
const char SENSOR_ERROR_UNSUSCRIBED[]    =  "UNSUSCRIBED_TOPIC"; // Received message on unsuscribed topic

//
// Topics to soscribe to
//
const char SENSOR_COMMAND_TOPIC[]        =  "sensor/command";      // To receive commands

//
// Available commands
//
const char ESP8266_SENSOR_COMMAND_STATUS[]       =  "status";   
const char ESP8266_SENSOR_COMMAND_STATISTICS[]   =  "stats";
const char ESP8266_SENSOR_COMMAND_RESTART[]      =  "restart";


//
// Standard return codes
//
const int ESP8266_SENSOR_RETCODE_OK              =     0;
const int ESP8266_SENSOR_RETCODE_MQTT_NOT_READY  = -9999;
const int ESP8266_SENSOR_RETCODE_JSON_OVERFLOW   = -9998;
const int ESP8266_SENSOR_RETCODE_MSG_TOO_LONG    = -9997;
const int ESP8266_SENSOR_RETCODE_SERIALIZE_ERR   = -9980;
const int ESP8266_SENSOR_RETCODE_PUBLISH_ERROR   = -9900;


#include <Arduino.h>

#endif
